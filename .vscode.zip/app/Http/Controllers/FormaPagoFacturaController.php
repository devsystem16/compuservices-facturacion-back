<?php

namespace App\Http\Controllers;

use App\Models\FormaPagoFactura;
use Illuminate\Http\Request;

class FormaPagoFacturaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FormaPagoFactura  $formaPagoFactura
     * @return \Illuminate\Http\Response
     */
    public function show(FormaPagoFactura $formaPagoFactura)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FormaPagoFactura  $formaPagoFactura
     * @return \Illuminate\Http\Response
     */
    public function edit(FormaPagoFactura $formaPagoFactura)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FormaPagoFactura  $formaPagoFactura
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FormaPagoFactura $formaPagoFactura)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\FormaPagoFactura  $formaPagoFactura
     * @return \Illuminate\Http\Response
     */
    public function destroy(FormaPagoFactura $formaPagoFactura)
    {
        //
    }
}
