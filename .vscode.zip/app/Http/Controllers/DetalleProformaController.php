<?php

namespace App\Http\Controllers;

use App\Models\DetalleProforma;
use Illuminate\Http\Request;

class DetalleProformaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DetalleProforma  $detalleProforma
     * @return \Illuminate\Http\Response
     */
    public function show(DetalleProforma $detalleProforma)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DetalleProforma  $detalleProforma
     * @return \Illuminate\Http\Response
     */
    public function edit(DetalleProforma $detalleProforma)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DetalleProforma  $detalleProforma
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetalleProforma $detalleProforma)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DetalleProforma  $detalleProforma
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetalleProforma $detalleProforma)
    {
        //
    }
}
